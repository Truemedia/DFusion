DROP TABLE #__jfusion;
DROP TABLE #__jfusion_users_plugin;
DROP TABLE #__jfusion_users;
DROP TABLE #__jfusion_sync;
