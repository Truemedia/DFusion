<?php

/**
* @package JFusion
* @subpackage Models
* @author JFusion development team
* @copyright Copyright (C) 2008 JFusion. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*/

// no direct access
defined('_JEXEC' ) or die('Restricted access' );

/**
* Class for general JFusion functions
* @package JFusion
*/

class JFusionFunction{

    /**
* Returns the JFusion plugin name of the software that is currently the master of user management
* @param string $jname Name of master JFusion plugin
*/

    function getMaster()
    {
        static $jfusion_master;
        if (!isset($jfusion_master )) {
          	$db = & JFactory::getDBO();
	        $query = 'SELECT * from #__jfusion WHERE master = 1 and status = 1';
    	    $db->setQuery($query );
        	$jfusion_master = $db->loadObject();
	        if ($jfusion_master) {
    	        return $jfusion_master;
        	}
        } else {
    	    return $jfusion_master;
        }
    }

    /**
* Returns the JFusion plugin name of the software that are currently the slaves of user management
* @param string $jname Name of master JFusion plugin
*/

    function getSlaves()
    {
        static $jfusion_slaves;
        if (!isset($jfusion_slaves )) {
	        $db = & JFactory::getDBO();
    	    $query = 'SELECT * from #__jfusion WHERE slave = 1 and status = 1';
        	$db->setQuery($query );
	        $jfusion_slaves = $db->loadObjectList();
        }
    	return $jfusion_slaves;
    }

    /**
* Returns the JFusion plugin name of the software that is currently the slave of user management, minus the joomla_int plugin
* @param array $jname Array list of slave JFusion plugin names
*/

    function getPlugins()
    {
        static $jfusion_plugins;
        if (!isset($jfusion_plugins )) {
	        $db = & JFactory::getDBO();
    	    $query = 'SELECT * from #__jfusion WHERE (slave = 1 AND status = 1 AND name NOT LIKE \'joomla_int\')';
	        $db->setQuery($query );
    	    $jfusion_plugins = $db->loadObjectList();
        }
        return $jfusion_plugins;
    }

    /**
* Returns the parameters of a specific JFusion integration
* @param string $jname name of the JFusion plugin used
* @return object Joomla parameters object
*/

    function &getParameters($jname)
    {
        //get the current parameters from the jfusion table
        $db = & JFactory::getDBO();
        $query = 'SELECT params from #__jfusion WHERE name = ' . $db->Quote($jname);
        $db->setQuery($query );
        $serialized = $db->loadResult();

        //get the parameters from the XML file
        $file = JPATH_ADMINISTRATOR .DS.'components'.DS.'com_jfusion'.DS.'plugins'.DS. $jname . DS.'jfusion.xml';

        $parametersInstance = new JParameter('', $file );

        //apply the stored valued
        if ($serialized) {
            $params = unserialize(base64_decode($serialized));

            if (is_array($params)) {
                foreach($params as $key => $value) {
                    $parametersInstance->set($key, $value );
                }
            }
        }

        if (!is_object($parametersInstance)) {
            JError::raiseError(500, JText::_('NO_FORUM_PARAMETERS'));
        }

        return $parametersInstance;
    }

    /**
* Saves the posted JFusion component variables
* @param string $jname name of the JFusion plugin used
* @param array $post Array of JFusion plugin parameters posted to the JFusion component
* @return true|false returns true if succesful and false if an error occurred
*/

    function saveParameters($jname, $post)
    {
        $mergedpost = array_merge((array) JFusionFunction::getparameters($jname)->_registry['_default']['data'],$post);
        //serialize the $post to allow storage in a SQL field
        $serialized = base64_encode(serialize($mergedpost));

        //set the current parameters in the jfusion table
        $db = & JFactory::getDBO();
        $query = 'UPDATE #__jfusion SET params = ' . $db->Quote($serialized) .' WHERE name = ' . $db->Quote($jname);
        $db->setQuery($query );

        if (!$db->query()) {
            //there was an error saving the parameters
            JError::raiseWarning(0,$db->stderr());
            $result = false;
            return $result;
        }

        $result = true;
        return $result;
    }

    /**
* Checks to see if the JFusion plugins are installed and enabled
*/
    function checkPlugin()
    {
        $userPlugin = true;
        $authPlugin = true;
        if (!JFusionFunction::isPluginInstalled('jfusion','authentication', false)) {
            JError::raiseWarning(0,JText::_('FUSION_MISSING_AUTH'));
            $authPlugin = false;
        }

        if (!JFusionFunction::isPluginInstalled('jfusion','user', false)) {
            JError::raiseWarning(0,JText::_('FUSION_MISSING_USER'));
            $userPlugin = false;
        }

        if ($authPlugin && $userPlugin) {
            $jAuth = JFusionFunction::isPluginInstalled('jfusion','user',true);
            $jUser = JFusionFunction::isPluginInstalled('jfusion','authentication',true);
            if (!$jAuth) {
                JError::raiseNotice(0,JText::_('FUSION_READY_TO_USE_AUTH'));
            }
            if (!$jUser) {
                JError::raiseNotice(0,JText::_('FUSION_READY_TO_USE_USER'));
            }
        }
    }


    /**
* Checks to see if the configuration of a Jfusion plugin is valid and stores the result in the JFusion table
* @param string $jname name of the JFusion plugin used
*/

    /**
* Tests if a plugin is installed with the specified name, where folder is the type (e.g. user)
* @param string $element element name of the plugin
* @param string $folder folder name of the plugin
* @param integer $testPublished Variable to determine if the function should test to see if the plugin is published
* @return true|false returns true if succesful and false if an error occurred
*/
    function isPluginInstalled($element,$folder, $testPublished)
    {
        $db =& JFactory::getDBO();
        $query = 'SELECT published FROM #__plugins WHERE element=' . $db->Quote($element) . ' AND folder=' . $db->Quote($folder);
        $db->setQuery($query);
        $result = $db->loadObject();
        if ($result) {
            if ($testPublished) {
                return($result->published == 1);
            } else {
	            $result = true;
    	        return $result;
            }
        } else {
            $result = false;
            return $result;
        }
    }

    /**
* Acquires a database connection to the database of the software integrated by JFusion
* @param string $jname name of the JFusion plugin used
* @return object JDatabase
*/
    function &getDatabase($jname)
    {
		//check to see if joomla DB is requested
		if ($jname == 'joomla_int'){
        	$db = & JFactory::getDBO();
        	return $db;
		}

        //get the debug configuration setting
        $conf =& JFactory::getConfig();
        $debug = $conf->getValue('config.debug');

        //TODO see if we can delete these jimports below
        jimport('joomla.database.database');
        jimport('joomla.database.table' );

        //get config values
        $conf =& JFactory::getConfig();
        $params = JFusionFactory::getParams($jname);

        //prepare the data for creating a database connection
        $host = $params->get('database_host');
        $user = $params->get('database_user');
        $password = $params->get('database_password');
        $database = $params->get('database_name');
        $prefix = $params->get('database_prefix');
        $driver = $params->get('database_type');
        $debug = $conf->getValue('config.debug');

		//added extra code to prevent error when $driver is incorrect
		if ($driver != 'mysql' && $driver != 'mysqli') {
			//invalid driver
            JError::raiseWarning(0, JText::_('INVALID_DRIVER'));
            $result = false;
            return $result;
		}

        //create an options variable that contains all database connection variables
        $options = array('driver' => $driver, 'host' => $host, 'user' => $user, 'password' => $password, 'database' => $database, 'prefix' => $prefix );

        //create the actual connection
        $jfusion_database =& JDatabase::getInstance($options );
        if (!method_exists($jfusion_database,'Execute')){
            JError::raiseWarning(0, JText::_('NO_DATABASE'));
            $result = false;
            return $result;
        } else {
	        //add support for UTF8
    	    $jfusion_database->Execute('SET names \'utf8\'');
    	    //support debugging
			$jfusion_database->debug($debug);
	        return $jfusion_database;
        }

    }

    /**
* Returns either the Joomla wrapper URL or the full URL directly to the forum
* @param string $url relative path to a webpage of the integrated software
* @param string $jname name of the JFusion plugin used
* @return string full URL to the filename passed to this function
*/

    function createURL($url, $jname, $view, $itemid='')
    {
    	if(!empty($itemid)){
            //use the itemid only to identify plugin name and view type
            $base_url = 'index.php?option=com_jfusion&amp;Itemid=' . $itemid;
    	} else {
            $base_url = 'index.php?option=com_jfusion&amp;view=' . $view . '&amp;jname=' . $jname;
    	}

		if ($view == 'direct') {
            $params = JFusionFactory::getParams($jname);
            $url = $params->get('source_url') . $url;
            return $url;
		} elseif ($view == 'wrapper') {
        	//use base64_encode to encode the URL for passing.  But, base64_code uses / which throws off SEF urls.  Thus slashes
        	//must be translated into something base64_encode will not generate and something that will not get changed by Joomla or Apache.
            $url = $base_url . '&amp;wrap='. str_replace("/","_slash_",base64_encode($url));
            $url = JRoute::_($url);
            return $url;
        } elseif ($view == 'frameless'){
            //split the filename from the query
            $parts = explode('?', $url);
            if (isset($parts[1])) {
            	$base_url .= '&amp;jfile=' . $parts[0] . '&amp;' . $parts[1];
            } else {
            	$base_url .= '&amp;jfile=' . $parts[0];
            }

            $url = JRoute::_($base_url);
        	return $url;
        }
    }

    /**
* Updates the JFusion user lookup table during login
* @param object $userinfo object containing the userdata
* @param string $jname name of the JFusion plugin used
* @param string $joomla_id The Joomla ID of the user
*/

    function updateLookup($userinfo, $jname, $joomla_id)
    {

        $db =& JFactory::getDBO();
        //prepare the variables
        $lookup = new stdClass;
        $lookup->userid = $userinfo->userid;
        $lookup->username = $userinfo->username;
        $lookup->jname = $jname;
        $lookup->id = $joomla_id;


        //insert the entry into the lookup table
        $db->insertObject('#__jfusion_users_plugin', $lookup, 'autoid' );
    }

    /**
* Returns the userinfo data for JFusion plugin based on the Joomla userid
* @param string $jname name of the JFusion plugin used
* @param string $userid The Joomla ID of the user
* @return object database Returns the userinfo as a Joomla database object
**/

    function lookupUser($jname, $userid)
    {
        $db =& JFactory::getDBO();
        $query = 'SELECT * FROM #__jfusion_users_plugin WHERE id =' . $userid . ' AND jname = ' . $db->Quote($jname);
        $db->setQuery($query);
        $result = $db->loadObject();
        return $result;
    }

    /**
* Checks to see if a JFusion plugin is properly configured
* @param string $jname name of the JFusion plugin used
* @return bolean returns true if plugin is correctly configured
*/

    function validPlugin($jname)
    {
        $db =& JFactory::getDBO();
        $query = 'SELECT status FROM #__jfusion WHERE name =' . $db->Quote($jname);
        $db->setQuery($query);
        $result = $db->loadResult();
		if ($result == '1') {
            $result = true;
            return $result;
		} else {
            $result = false;
            return $result;
		}
    }

    function removeUser($userinfo)
    {
    	//Delete old user data in the lookup table
		$db =& JFactory::getDBO();
        $query = 'DELETE FROM #__jfusion_users WHERE id =' . $userinfo->userid . ' OR username =' . $db->Quote($userinfo->username);
       	$db->setQuery($query);
		if(!$db->query()) {
            JError::raiseWarning(0,$db->stderr());
        }

        $query = 'DELETE FROM #__jfusion_users_plugin WHERE id =' . $userinfo->userid ;
       	$db->setQuery($query);
	    if(!$db->query()) {
       		JError::raiseWarning(0,$db->stderr());
   		}

    }

    function addCookie($name, $value, $expires_time, $cookiepath, $cookiedomain, $httponly)
    {
    	if($expires_time != 0) {
			$expires = time() + intval($expires_time);
    	} else {
    		$expires = 0;
    	}

        // Versions of PHP prior to 5.2 do not support HttpOnly cookies and IE is buggy when specifying a blank domain so set the cookie manually
        $cookie = "Set-Cookie: {$name}=".urlencode($value);
        if ($expires > 0) {
            $cookie .= "; expires=".gmdate('D, d-M-Y H:i:s \\G\\M\\T', $expires);
        }
        if (!empty($cookiepath)) {
            $cookie .= "; path={$cookiepath}";
        }
        if (!empty($cookiedomain)) {
            $cookie .= "; domain={$cookiedomain}";
        }
        if ($httponly == true) {
            $cookie .= "; HttpOnly";
        }

   		header($cookie, false);

        //$document	= JFactory::getDocument();
	    //$document->addCustomTag($cookie);

    }

    function raiseWarning($type, $warning, $jerror){
    	if(is_array($warning)){
			foreach ($warning as $warningtext){
				if ($jerror){
					JError::raiseWarning('500', $type . ': '. $warningtext);
				} else {
					echo $type . ': '. $warningtext . '<br/>';
				}
			}
    	} else {
    		if ($jerror) {
				JError::raiseWarning('500', $type .': '. $warning);
    		} else {
				echo $type . ': '. $warning . '<br/>';
    		}
    	}
    }

	function phpinfo_array(){
		//get the phpinfo and parse it into an array
		ob_start();
		phpinfo();
		$phpinfo = array('phpinfo' => array());
		if(preg_match_all('#(?:<h2>(?:<a name=".*?">)?(.*?)(?:</a>)?</h2>)|(?:<tr(?: class=".*?")?><t[hd](?: class=".*?")?>(.*?)\s*</t[hd]>(?:<t[hd](?: class=".*?")?>(.*?)\s*</t[hd]>(?:<t[hd](?: class=".*?")?>(.*?)\s*</t[hd]>)?)?</tr>)#s', ob_get_clean(), $matches, PREG_SET_ORDER))
    	foreach($matches as $match)
        if(strlen($match[1]))
        $phpinfo[$match[1]] = array();
        elseif(isset($match[3]))
        $phpinfo[end(array_keys($phpinfo))][$match[2]] = isset($match[4]) ? array($match[3], $match[4]) : $match[3];
        else
        $phpinfo[end(array_keys($phpinfo))][] = $match[2];

        return $phpinfo;
	}

    function displayDonate(){
    	?>
<table class="adminform"><tr><td style="width:90%;"><font size="3"><b><?php echo JText::_('DONATION_MESSAGE'); ?></b></font></td><td style="width:10%; text-align:right;">
<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_donations"/>
<input type="hidden" name="business" value="webmaster@jfusion.org"/>
<input type="hidden" name="item_name" value="jfusion.org"/>
<input type="hidden" name="no_shipping" value="0"/>
<input type="hidden" name="no_note" value="1"/>
<input type="hidden" name="currency_code" value="AUD"/>
<input type="hidden" name="tax" value="0"/>
<input type="hidden" name="lc" value="AU"/>
<input type="hidden" name="bn" value="PP-DonationsBF"/>
<input type="image" src="components/com_jfusion/images/donate.png" name="submit" alt="PayPal donation button."/>
<img alt="" border="0" src="https://www.paypal.com/en_AU/i/scr/pixel.gif" width="1" height="1"/>
</form></td></tr></table>

    	<?php

    }

    function updateForumLookup($contentid, $threadid, $postid, $jname)
    {
        $db =& JFactory::getDBO();
		$modified = time();

		//check to see if content item has already been created in forum software
        $query = 'SELECT COUNT(*) FROM #__jfusion_forum_plugin WHERE contentid = ' . $contentid . ' AND jname = ' . $db->Quote($jname);
        $db->setQuery($query);
	    if($db->loadResult() == 0)
	    {
	    	//content item has not been created
	        //prepare the variables
	        $lookup = new stdClass;
	        $lookup->contentid = $contentid;
	        $lookup->threadid = $threadid;
	        $lookup->postid = $postid;
	        $lookup->modified = $modified;
	        $lookup->jname = $jname;

	        //insert the entry into the lookup table
	        $db->insertObject('#__jfusion_forum_plugin', $lookup);
	    }
	    else
	    {
	    	//content itmem has been created so updated variables to prevent duplicate threads
	    	$query = "UPDATE #__jfusion_forum_plugin SET threadid = {$threadid}, postid = {$postid}, modified = {$modified} WHERE contentid = {$contentid} AND jname = {$db->Quote($jname)}";
	    	$db->setQuery($query);
	    	$db->query();
	    }
    }

    function createJoomlaArticleURL(&$contentitem,$text)
    {
    	//jimport('joomla.application.component.controller');
    	$itemid = ContentHelper::getItemid($contentitem->id, $contentitem->catid, $contentitem->sectionid);
		$link = JRoute::_('index.php?option=com_content&view=article&id=' . $contentid.'&Itemid='.$itemid);
		$link = "<a href='$link'>$text</a>";
		return $link;
    }
    
    function parseCode($to='bbcode',$text)
    {
    	
    	global $smiley_folder, $cb_guide_path, $use_pajamas, $prevent_spam, $spammer_strings, $spammer_agents,  $prevent_xss, $cb_ref_title;
    	include_once('cbparser/cbparser.php');
    	if($to=="bbcode") {
   			$converted = html2bb($text);
	
    	} elseif($to=="html") {
    		$converted = bb2html($text);
    	}
    	
		if ($converted == ''){
			JError::raiseWarning(500, JText::_('CODE_PARSE_ERROR'));
			$converted = $text;
		}

		return $converted;
    }
}