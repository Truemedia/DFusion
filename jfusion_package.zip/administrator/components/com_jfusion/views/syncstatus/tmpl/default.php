<?php
/**
* @package JFusion
* @subpackage Views
* @author JFusion development team
* @copyright Copyright (C) 2008 JFusion. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

/**
* 	Load debug library
*/
//require_once(JPATH_ADMINISTRATOR .DS.'components'.DS.'com_jfusion'.DS.'models'.DS.'model.debug.php');
//debug::show($this->syncdata, JText::_('SERVER') . ' ' . JText::_('CONFIGURATION'),1);
//return;

//check to see if there is anything to output
if (!$this->syncdata['slave_data']){
	echo JText::_('SYNC_NODATA');
    return;
} elseif (!empty($this->syncdata['completed'])) {
	echo '<br/><br/><br/>';
	//check to see if there were any errors
	if (!empty($this->syncdata['errors'])) {
		//redirect to resolve errors
		echo '<h2><a href="index.php?option=com_jfusion&task=syncerror&syncid=' . $this->syncdata['syncid'] . '">' . JText::_('SYNC_CONFLICT') . '</a></h2>';
	} else {
		//inform about the success
		echo '<h2>' . JText::_('SYNC_SUCCESS') . '</h2>';
	}

} else {
	echo '<br/><br/><br/>';
}

?>

<h2><?php echo JText::_('SYNC_STATUS');?></h2>

<table class="adminlist" cellspacing="1"><thead><tr><th width="50px">
<?php echo JText::_('PLUGIN'). ' ' . JText::_('NAME');
?>
</th><th>
<?php echo JText::_('SYNC_USERS_TODO');
?>
</th><th>
<?php echo JText::_('USERS') . ' ' . JText::_('UNCHANGED');
?>
</th><th>
<?php echo JText::_('USERS') . ' ' . JText::_('UPDATED');
?>
</th><th>
<?php echo JText::_('USERS') . ' ' . JText::_('CREATED');
?>
</th><th>
<?php echo JText::_('USERS') . ' ' . JText::_('DELETED');
?>
</th><th>
<?php echo JText::_('USER') . ' ' . JText::_('CONFLICTS');
?>
</th></tr></thead>

<?php foreach ($this->syncdata['slave_data'] as $slave) {
?>
<tr><td>
<?php echo $slave['jname'];?>
</td><td>
<?php echo $slave['total'];?>
</td><td>
<?php echo $slave['unchanged'];?>
</td><td>
<?php echo $slave['updated'];?>
</td><td>
<?php echo $slave['created'];?>
</td><td>
<?php echo $slave['deleted'];?>
</td><td>
<?php echo $slave['error'];?>
</td></tr>

<?php } ?>
</table></form>