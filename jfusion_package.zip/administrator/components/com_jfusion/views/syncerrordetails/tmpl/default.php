<?php
/**
* @package JFusion
* @subpackage Views
* @author JFusion development team
* @copyright Copyright (C) 2008 JFusion. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

?>
<style type="text/css">
#ajax_bar {
    background-color: #7fa9ff;
    border: 1px solid #d6d6d6;
    border-left-color: #e4e4e4;
    border-top-color: #e4e4e4;
    margin-top: 0pt auto;
    height: 20px;
    padding: 3px 5px;
    vertical-align: center;
}
</style>


<div id="ajax_bar"><font size="3">Detailed JFusion Error Report</font></div>

<?php

//check to see if the sync has already started
$syncid = JRequest::getVar('syncid', '', 'GET');
$syncdata = JFusionUsersync::getSyncdata($syncid);

//get the error
$errorid = JRequest::getVar('errorid', '', 'GET');
$error =  $syncdata['errors'][$errorid];

//display the userlist info
debug::show($error['user']['jname'], 'User from Plugin',1);
echo '<br/>';
debug::show($error['user']['userlist'], 'User Info from Usersync List',1);
echo '<br/>';
debug::show($error['user']['userinfo'], 'User Info from getUser() function');
echo '<br/>';
debug::show($error['conflict']['jname'], 'User target Plugin',1);
echo '<br/>';
debug::show($error['conflict']['error'], 'Error Info from updateUser() function');
echo '<br/>';
debug::show($error['conflict']['debug'], 'Debug Info from updateUser() function');
echo '<br/>';
debug::show($error['conflict']['userinfo'], 'User Info from updateUser() function');


